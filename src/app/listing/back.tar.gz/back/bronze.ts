// <reference path="medal.ts" />
import { Listing } from './listing';
// import { Medal } from './medal';

namespace Model {

    export class Bronze extends Model.Medal {
        public weight = 1;

        public sortStrategy( a:Listing, b:Listing ) {
            return (a,b) => 
                a.numBronze < b.numBronze? 1: a.numBronze > b.numBronze? -1: 
                a.scoreHash < b.scoreHash? 1: a.scoreHash > b.scoreHash? -1: 0;
        }
    }
}