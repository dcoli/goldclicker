namespace Model {

    export class NewMedal {
        public label = this.constructor.name;
        public isSelected = false;
    }

}
